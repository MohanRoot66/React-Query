import React from "react";
import { useQuery } from "@tanstack/react-query";
import Item from "../features/Item";
import { URL } from "../Url";

const retrievePosts = async () => {
  const response = await fetch(URL);
  return response.json();
};

const DisplayPosts = () => {
  const { data: posts, error, isLoading } = useQuery(
    {
      queryKey:["posts"],
      queryFn:retrievePosts
    }
  );
  if (isLoading) return <div>Fetching posts...</div>;
  if (error) return <div>An error occurred: {error.message}</div>;

  return (
    <div style={{ listStyle: "none" }}>
      {posts.map((post) => (
        
        <Item key={post.id} post={post} />
      ))}
    </div>
  );
  
};

export default DisplayPosts;