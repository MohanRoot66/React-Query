import { faker } from '@faker-js/faker';
import { URL } from '../Url';

export default async function CreatePost() {
    const obj = {
      title: faker.lorem.paragraph(),
    };
  
   // console.log(obj);
  
    const response = await fetch(URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(obj),
    });
  
    if (response.ok) {
      return response.json(); // Return the parsed JSON data
    }
  
    throw new Error(response.statusText);
  }
  
