import { URL } from "../Url";
export default async function deletePost(id)
{
   const response = await fetch(`${URL}/${id}`,
   {
        method:"delete",
        headers:
        {
            "Content-Type": "application/json",
        },
   })

   if(response.ok)
   {
    return "Deleted Successfully"
   }
   return response.error;
}