import { useMutation, useQueryClient } from "@tanstack/react-query";
import DisplayPosts from "./Services/DisplayPosts";
import CreatePost from "./Services/CreatePost";


export default function App() {
  const querclient = useQueryClient();
  console.log(querclient);
  const { mutate } = useMutation({
    mutationFn: CreatePost,
    onSuccess: () => {
      querclient.invalidateQueries("posts");
    },
    onError: (error) => {
      console.error("Error adding post:", error.message);
      // Optionally, display an error message to the user
    },
  });
  
  return (
    <>
      <button onClick={() => mutate()}>Create a Post</button>
      <DisplayPosts />
    </>
  );
}
