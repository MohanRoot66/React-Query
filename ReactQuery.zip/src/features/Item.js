// CardComponent.js
import { useMutation, useQueryClient } from '@tanstack/react-query';
import React from 'react';
import updatePost from '../Services/UpdatePost';
import deletePost from '../Services/DeletePost';

const Item = ({post}) => {

    const queryclient = useQueryClient();

    const {mutate:deleteData}=useMutation(
        {
          mutationFn:(id)=>deletePost(id),
          onSuccess:(data)=>
          {
            alert(data)
            queryclient.invalidateQueries("posts");
          },
          onError:(err)=>
          {
            console.log(err.message)
          }
        }
    );
    const {mutate:updateData}=useMutation(
        {
          mutationFn:(id)=>updatePost(id),
          onSuccess:(data)=>
          {
            alert(data)
            queryclient.invalidateQueries("posts");
          },
          onError:(err)=>
          {
            console.log(err.message)
          }
        }
    );

  return (
    <div style={cardStyle}>
        <p>title : {post.title}</p>
        <button onClick={()=>updateData(post.id)}>Update</button>
        <button onClick={()=>deleteData(post.id)}>Delete</button>
   </div>
  );
};

// Styles for the card div
const cardStyle = {
  border: '1px solid #ddd',
  borderRadius: '8px',
  padding: '16px',
  margin: '16px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
};

export default Item;
